(function ($) {
    $(document).ready(function () {
        var $window = $(window);
        $window.on('load',function () {
            /*Only for test my js file*/
            console.log('salam gholam');

        });


    });

})(jQuery);